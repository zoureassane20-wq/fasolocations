# FasoLocations

Site vitrine/catalogue responsive pour une plateforme de location de matériel.

## Démarrage
1. Ouvre `index.html` dans un navigateur.
2. Modifie le numéro WhatsApp dans `script.js` :
   `whatsapp: "22670000000"`
3. Modifie les exemples de locations dans `rentals`.
4. Modifie les prix des matériaux dans `materials`.

## Mise en ligne gratuite
Le site est statique : il peut être publié avec GitHub Pages, Netlify ou Cloudflare Pages.

## Important
Les prix fournis dans cette démo sont fictifs/indicatifs. Ils doivent être remplacés par les prix réels de la zone ciblée avant publication commerciale.
