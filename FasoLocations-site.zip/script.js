const CONFIG = {
  siteName: "FasoLocations",
  whatsapp: "22670000000", // REMPLACE par ton numéro WhatsApp avec indicatif pays, sans + ni espaces
  currency: "FCFA"
};

const categories = [
  ["construction","🏗️","Construction"],
  ["vehicules","🚗","Véhicules"],
  ["ceremonie","🎉","Cérémonie"],
  ["outillage","🔧","Outillage"],
  ["maison","🏠","Maison"],
  ["electrique","⚡","Électricité"],
  ["agriculture","🚜","Agriculture"],
  ["autres","📦","Autres"]
];

const rentals = [
  {name:"Bétonnière 350 L",cat:"construction",city:"Ouagadougou",price:15000,unit:"jour",img:"https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=900&q=80"},
  {name:"Échafaudage métallique",cat:"construction",city:"Ouagadougou",price:5000,unit:"jour",img:"https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=900&q=80"},
  {name:"Marteau-piqueur",cat:"outillage",city:"Bobo-Dioulasso",price:10000,unit:"jour",img:"https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?auto=format&fit=crop&w=900&q=80"},
  {name:"Toyota Hilux",cat:"vehicules",city:"Ouagadougou",price:35000,unit:"jour",img:"https://images.unsplash.com/photo-1559416523-140ddc3d238c?auto=format&fit=crop&w=900&q=80"},
  {name:"Chaises de cérémonie",cat:"ceremonie",city:"Koudougou",price:150,unit:"chaise/jour",img:"https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=900&q=80"},
  {name:"Groupe électrogène 5 kVA",cat:"electrique",city:"Ouagadougou",price:12000,unit:"jour",img:"https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&w=900&q=80"},
  {name:"Motopompe",cat:"agriculture",city:"Banfora",price:9000,unit:"jour",img:"https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&w=900&q=80"},
  {name:"Canapé salon",cat:"maison",city:"Ouagadougou",price:8000,unit:"jour",img:"https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=80"}
];

const materials = [
  ["Ciment 32,5", "sac 50 kg", 6000, "Ciment"],
  ["Ciment 42,5", "sac 50 kg", 7000, "Ciment"],
  ["Fer à béton Ø6", "barre", 1800, "Fer"],
  ["Fer à béton Ø8", "barre", 2800, "Fer"],
  ["Fer à béton Ø10", "barre", 4300, "Fer"],
  ["Fer à béton Ø12", "barre", 6000, "Fer"],
  ["Sable fin", "m³", 18000, "Granulats"],
  ["Gravier", "m³", 22000, "Granulats"],
  ["Briques creuses", "unité", 250, "Maçonnerie"],
  ["Parpaing", "unité", 300, "Maçonnerie"],
  ["Tôle bac", "mètre", 6500, "Toiture"],
  ["Bois de coffrage", "pièce", 5000, "Bois"]
];

const money = n => new Intl.NumberFormat("fr-FR").format(n) + " " + CONFIG.currency;
const wa = text => `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(text)}`;

document.getElementById("year").textContent = new Date().getFullYear();

const nav = document.getElementById("nav");
document.getElementById("menuBtn").onclick = () => nav.style.display = nav.style.display === "flex" ? "none" : "flex";

document.getElementById("floatingWhatsApp").href = wa("Bonjour FasoLocations, je souhaite avoir des informations.");
document.getElementById("contactWhatsApp").href = wa("Bonjour FasoLocations, j'ai besoin d'informations.");
document.getElementById("publishWhatsApp").href = wa("Bonjour FasoLocations, je souhaite publier un matériel à louer.");

document.getElementById("categories").innerHTML = categories.map(([id,icon,name]) =>
  `<div class="category" onclick="selectCategory('${id}')"><div class="category-icon">${icon}</div><strong>${name}</strong><small>Voir les annonces</small></div>`
).join("");

const categoryFilter = document.getElementById("categoryFilter");
categoryFilter.innerHTML += categories.map(([id,_,name]) => `<option value="${id}">${name}</option>`).join("");
const cityFilter = document.getElementById("cityFilter");
[...new Set(rentals.map(x=>x.city))].sort().forEach(c => cityFilter.innerHTML += `<option>${c}</option>`);

function selectCategory(id){
  categoryFilter.value = id;
  renderRentals();
  document.getElementById("locations").scrollIntoView({behavior:"smooth"});
}

function renderRentals(){
  const q = document.getElementById("search").value.toLowerCase().trim();
  const cat = categoryFilter.value;
  const city = cityFilter.value;
  const list = rentals.filter(x =>
    (!q || `${x.name} ${x.city}`.toLowerCase().includes(q)) &&
    (cat==="all" || x.cat===cat) &&
    (city==="all" || x.city===city)
  );
  const el = document.getElementById("rentalCards");
  el.innerHTML = list.length ? list.map(x => {
    const label = categories.find(c=>c[0]===x.cat)?.[2] || "Autres";
    const msg = `Bonjour FasoLocations, je suis intéressé(e) par "${x.name}" à ${money(x.price)}/${x.unit}. Est-il disponible ?`;
    return `<article class="card">
      <img src="${x.img}" alt="${x.name}" loading="lazy">
      <div class="card-body">
        <span class="tag">${label}</span>
        <h3>${x.name}</h3>
        <div class="price">${money(x.price)} <small>/${x.unit}</small></div>
        <div class="card-meta"><span>📍 ${x.city}</span><span>✓ Disponible</span></div>
        <div class="card-actions">
          <a class="btn whatsapp" href="${wa(msg)}" target="_blank">WhatsApp</a>
          <a class="btn call" href="tel:+${CONFIG.whatsapp}">Appeler</a>
        </div>
      </div>
    </article>`;
  }).join("") : `<p class="muted">Aucun matériel ne correspond à votre recherche.</p>`;
}
["search","categoryFilter","cityFilter"].forEach(id=>document.getElementById(id).addEventListener("input",renderRentals));
renderRentals();

const materialCategory = document.getElementById("materialCategory");
[...new Set(materials.map(x=>x[3]))].forEach(c=>materialCategory.innerHTML += `<option>${c}</option>`);

function renderMaterials(){
  const q = document.getElementById("materialSearch").value.toLowerCase().trim();
  const cat = materialCategory.value;
  const rows = materials.filter(x=>(!q || x[0].toLowerCase().includes(q)) && (cat==="all" || x[3]===cat));
  document.getElementById("priceRows").innerHTML = rows.map(x =>
    `<tr><td><strong>${x[0]}</strong></td><td>${x[1]}</td><td><strong>${money(x[2])}</strong></td><td>${x[3]}</td></tr>`
  ).join("") || `<tr><td colspan="4">Aucun résultat.</td></tr>`;
}
["materialSearch","materialCategory"].forEach(id=>document.getElementById(id).addEventListener("input",renderMaterials));
renderMaterials();
